// Lab 2 - Part 2 - Coin Toss Simulator

package cointoss;

public class Coin {
	
	// Constant used for Calculating Heads or Tails
	public static final double VALUE_HALF = 0.5;
	public static final int HEADS = 1;
	public static final int TAILS = 0;
	
	
	private int sideUp; 
	
	
	// No-arg Constructor
	public Coin() {
		setSideUp();
	}
	
	
	// Gets the coin side facing up
	public int getSideUp() {
		return this.sideUp;
	}
	
	
	// Sets coin side up
	public void setSideUp() {
		// Random value selects heads if less than 0.5
		if (Math.random() < VALUE_HALF) {
			this.sideUp = HEADS;
		} else {
			this.sideUp = TAILS;
		}
	}
	
	
	// Creates array of coins
	public static int[] toss() {
		
		// Declares Variables for Counter
		int heads = 0;
		int tails = 0;
		
		// Create array to store Coins
		Coin[] coinResults = new Coin[20];

		// Create 20 tossed coins
		for (int i = 0; i < 20; i++) {
				
			// Create coin object
			Coin singleCoin = new Coin();
				
			singleCoin.setSideUp();
				
			// Counter
			if (singleCoin.getSideUp() == HEADS) {
				heads++;
			} else {
				tails++;
			}
		
			// Assigning tossed coins to its index
			coinResults[i] = singleCoin;
			
		}
		
		// Return array that stores heads and tails number
		return new int[] {heads, tails};
	}
			
	// Main Class
	public static void main (String[] args) {
		
		int[] tossResult = toss();
		
		// Shows results of heads
		System.out.println("The coin flipped heads " + tossResult[0] + " time(s).");
		// Shows results of tails
		System.out.println("The coin flipped tails " + tossResult[1] + " time(s).");
		
	}
	
}