// import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		// Creates FileIO object to read data from the file
		FileIO a1 = new FileIO("C:\\Users\\yuuyu\\Documents\\Eclipse Workspace\\assignment336b\\src\\Salesdat.txt");
		
		// Read data from the file and store it in a Franchise object
		Franchise f = a1.readData();
		
		// Define Variable
		int numOfStores = 5;

		// For printing all data
		for (int i = 0; i < numOfStores; i++) {
			System.out.println("\n\nStore " + (i + 1));
			System.out.println("========================");
			
			// Call the businessMethod of the i'th store to print its sale data
			f.getStores(i).businessMethod(5, 7);
			
		}
		
		/*
		Scanner scanner = new Scanner(System.in);

	    System.out.println("Please select a store (1-5): ");
	    int storeNumber = scanner.nextInt();
	    System.out.println("Please select an option (a-f): ");
	    char infoOption = scanner.next().charAt(0);

	    scanner.close();
	    
	    System.out.println("\nStore " + (storeNumber));
		System.out.println("========================");
		f.getStores(storeNumber - 1).businessMethod(5, 7); 
		*/
		
	}

}