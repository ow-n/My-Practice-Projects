public class Store {
	private float salesByWeek[][];

	
	Store() {
		salesByWeek = new float[5][7];
	}

	
	// Getter and Setters
	public void setSaleForWeekdayIntersection(int week, int day, float sale) {
		salesByWeek[week][day] = sale;
	}

	public void printData() {
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 7; j++) {
				System.out.print(salesByWeek[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
	float [] getSalesForEntireWeek(int week) {
		return salesByWeek[week];
	}
	
	 float getSaleForWeekdayIntersection(int week, int day) {
		 return salesByWeek[week][day];
	 }
	 
	 
	 // businessMethod Method
	 public void businessMethod(int week, int day) {
        float totalSalesForWeek[] = new float[5];
        float avgSalesForWeek[] = new float[5];
        float totalSalesForAllWeeks = 0.0f;
        float averageWeeklySales = 0.0f;
        int weekWithHighestSaleAmt = 0;
        int weekWithLowestSaleAmt = 0;

        // Calculate totalSalesForWeek and totalSalesForAllWeeks
        for (int i = 0; i < 5; i++) {
            float totalSales = 0.0f;
            for (int j = 0; j < 7; j++) {
                totalSales += salesByWeek[i][j];
                totalSalesForAllWeeks += salesByWeek[i][j];
            }
            totalSalesForWeek[i] = totalSales;
        }

        // Calculate avgSalesForWeek and averageWeeklySales
        for (int i = 0; i < 5; i++) {
            avgSalesForWeek[i] = totalSalesForWeek[i] / 7.0f;
            averageWeeklySales += totalSalesForWeek[i];
        }
        averageWeeklySales /= 5.0f;

        // Find weekWithHighestSaleAmt and weekWithLowestSaleAmt
        for (int i = 1; i < 5; i++) {
            if (totalSalesForWeek[i] > totalSalesForWeek[weekWithHighestSaleAmt]) {
                weekWithHighestSaleAmt = i;
            }
            if (totalSalesForWeek[i] < totalSalesForWeek[weekWithLowestSaleAmt]) {
                weekWithLowestSaleAmt = i;
            }
        }

        // Print the results
        System.out.println("a. totalSalesForWeek: ");
        for (int i = 0; i < 5; i++) {
            System.out.printf("Week %d: $%.2f\n", i + 1, totalSalesForWeek[i]);
        }

        System.out.println("b. avgSalesForWeek: ");
        for (int i = 0; i < 5; i++) {
            System.out.printf("Week %d: $%.2f\n", i + 1, avgSalesForWeek[i]);
        }

        System.out.printf("c. totalSalesForAllWeeks: $%.2f\n", totalSalesForAllWeeks);

        System.out.printf("d. averageWeeklySales: $%.2f\n", averageWeeklySales);

        System.out.printf("e. weekWithHighestSaleAmt: Week %d\n", weekWithHighestSaleAmt + 1);
        
        System.out.printf("f. weekWithLowestSaleAmt: Week %d", weekWithLowestSaleAmt + 1);
	 }
	        
	 
        public void print(int week, int day) {
            printData();
            businessMethod(week, day);
        }	 
}